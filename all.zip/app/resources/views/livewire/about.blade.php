<div>
    <div>
        <div class="max-w-4xl mx-auto py-20 prose lg:prose-xl">
            <h1>BlogX</h1>
            <p>Blog? Bukan. Ini BlogX. Sebuah aplikasi yang dibuat menggunakan Laravel untuk membuat blog.</p>
            <p> Jadi BlogX itu apa?</p>
            <p> Ya BlogX itu BlogX</p>
        </div>
    </div>
</div>
