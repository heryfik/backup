<div>
    <div class="max-w-4xl mx-auto py-20 prose lg:prose-xl">
        <h1 class="truncate">{{ $post->title }}</h1>
        <p class="overflow-ellipsis overflow-hidden">{{ $post->body }}</p>    
    </div>
</div>
